﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2;

namespace TestChess
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Введите размерность доски (n x n) = ");
            int n = int.Parse(Console.ReadLine());
            if (n <= 0) Console.WriteLine("Такую доску нельзя нарисовать((");
            else
            {
                for (; ; )
                {
                    Console.WriteLine("1.Определить количество черных ячеек");
                    Console.WriteLine("2.Определить цвет ячейки по ее координатам");
                    Console.WriteLine("3.Определить являются ли ячейки одинаковыми");
                    Console.WriteLine("4.Находится ли фигура под ударом другой фигуры");
                    Console.WriteLine("0.Выход из программы");
                    Console.WriteLine("=============================================");
                    Console.Write("Что вы хотите? : ");

                    int k, m;
                    int choose;
                    var check = int.TryParse(Console.ReadLine(), out choose);
                    if (check)
                    {
                        switch (choose)
                        {
                            case 1:
                                Console.Clear();
                                WriteBoard(n);
                                Chess.CountBlack(n);
                                Console.WriteLine("=============================================");
                                break;
                            case 2:
                                Console.Clear();
                                WriteBoard(n);
                                Console.WriteLine("Введите координаты искомой ячейки");
                                k = int.Parse(Console.ReadLine());
                                m = int.Parse(Console.ReadLine());
                                if ((k > n || k < 0) || (m > n || m < 0)) Console.WriteLine("Размерность доски меньше! Искомой ячейки не существует");
                                else
                                    Chess.WhatColor(k, m);
                                Console.WriteLine("=============================================");
                                break;
                            case 3:
                                Console.Clear();
                                WriteBoard(n);
                                Console.WriteLine("Введите координаты ячейки 1");
                                int k1 = int.Parse(Console.ReadLine());
                                int k2 = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите координаты ячейки 2");
                                int m1 = int.Parse(Console.ReadLine());
                                int m2 = int.Parse(Console.ReadLine());
                                Chess.OneColor(k1, m1, k2, m2);
                                break;
                            case 4:
                                Console.Clear();
                                WriteBoard(n);
                                Console.WriteLine("Введите координаты фигуры 1");
                                k1 = int.Parse(Console.ReadLine());
                                m1 = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите координаты фигуры 2");
                                k2 = int.Parse(Console.ReadLine());
                                m2 = int.Parse(Console.ReadLine());
                                Console.WriteLine("Выберите фигуру 2 для проверки удара фигуры 1\n" +
                                    "0: пешка\n" +
                                    "1: cлон\n" +
                                    "2: ладья\n" +
                                    "3: ферзь\n");
                                Console.Write("Ваш выбор: ");
                                int choice = int.Parse(Console.ReadLine());
                                Chess.War(k1, m1, k2, m2,choice);
                                Console.WriteLine("=============================================");
                                break;
                        }
                        if (choose == 0)
                            break;
                    }
                }
            }
        }

        private static void WriteBoard(int size)
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if ((i + j) % 2 == 0) Console.Write("#");
                    else Console.Write(".");
                }
                Console.WriteLine("");
            }
            Console.WriteLine("");
        }
    }
}
