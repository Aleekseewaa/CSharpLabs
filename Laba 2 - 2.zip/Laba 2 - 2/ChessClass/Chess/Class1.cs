﻿using System;

namespace Task2
{
    public class Chess
    {
        public static void CountBlack(int n)
        {
            int count = 0;
            int board = n * n;
            for (int i = 0; i < board; i++)
            {
                if (i % 2 == 0) count++;
            }
            Console.WriteLine("На шахматной доске {0} черных клеток", count);
        }

        public static void WhatColor(int k, int m)
        {
            if ((k % 2 != 0 && m % 2 != 0) || (k % 2 == 0 && m % 2 == 0))
                Console.WriteLine("Черная ячейка");
            else
                Console.WriteLine("Белая ячейка");
        }

        public static void OneColor(int k1, int m1, int k2, int m2)
        {
            if ((k1 % 2 != 0 && m1 % 2 != 0) || (k1 % 2 == 0 && m1 % 2 == 0))
                if ((k2 % 2 != 0 && m2 % 2 != 0) || (k2 % 2 == 0 && m2 % 2 == 0))
                    Console.WriteLine("Ячейки одного цвета");
                else Console.WriteLine("Ячейки разного цвета");
        }

        public static void War(int k1, int m1, int k2, int m2, int choice)
        {
            bool pawn = false, elephant = false, rook = false, queen = false;

            if (k1 == k2 && m1 == m2) Console.WriteLine("Фигуры не могут стоять на одной клетке");
            else
            {
                if (m2 - m1 == 1 || (k2 - k1 == 1 || k2 - k1 == -1)) pawn = true;
                else
                if (Math.Abs(k1 - k2) == Math.Abs(m1 - m2)) elephant = true;
                else
                if (k2 == k1 || m2 == m1) rook = true;
                else
                if (m1 == m2 || k1 == k2 || (Math.Abs(k2 - k1) == Math.Abs(m1 - m2))) queen = true;
            }

            switch (choice)
            {
                case 0:
                    if (pawn) Console.WriteLine("Фигура находится под ударом пешки");
                    else Console.WriteLine("Фигура не находится под ударом пешки");
                    break;
                case 1:
                    if (elephant) Console.WriteLine("Фигура находится под ударом слона");
                    else Console.WriteLine("Фигура не находится под ударом слона");
                    break;
                case 2:
                    if (rook) Console.WriteLine("Фигура находится под ударом ладьи");
                    else Console.WriteLine("Фигура не находится под ударом ладьи");
                    break;
                case 3:
                    if (queen) Console.WriteLine("Фигура находится под ударом ферзя");
                    else Console.WriteLine("Фигура не находится под ударом ферзя");
                    break;
            }
        }
    }
}
